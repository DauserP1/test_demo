# habini1
Graduation Project
ddddd
Most social media platform are geared toward talking to people you already,
or at least know they have something in common with you. There isn’t a
platform that allows you to share something that’s not common between
people and still get reactions and have some interactive experiences, as most
there is a program as far as we can tell that links the posts you see geographically, there’s features in some apps, but at that point the time line is
so bloated that there’s isn’t roam for your niches.

5abini is an app that was built while focusing on privacy and intention to
gather people with no social fear or anxiety. To build an environment that
allows you to share what you love, care about, ask questions and help people
who do so. 5abini is geared into anonymous interactions, that will remove
fear of social criticism and anxiety, as who you are will never be unknown.
Make friends, get knowledge and share yours!
